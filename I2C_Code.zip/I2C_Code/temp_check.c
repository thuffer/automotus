#include <sys/types.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include "i2c/i2c.h"

#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define DEBUG 0

FILE *fp;
FILE *GPIO0;
FILE *GPIO1;

void handle_sigint(int sig)
{
    printf("Caught signal %d\n", sig);
    fclose(fp);
    exit(0);
}

void waitFor (unsigned int secs) {
    unsigned int retTime = time(0) + secs;   // Get finishing time.
    while (time(0) < retTime);               // Loop until it arrives.
}

char* toBinary(int n)
{
    int len = 8;
    char* binary = (char*)malloc(sizeof(char) * len);
    int k = 0;
    for (unsigned i = (1 << len - 1); i > 0; i = i / 2) {
        binary[k++] = (n & i) ? '1' : '0';
    }
    binary[k] = '\0';
    return binary;
}
/*
void setup()
{
    Serial.begin(115200);
    Serial.println("AHT20 DEMO");
    AHT.begin();
}

void loop()
{
    float humi, temp;
    
    int ret = AHT.getSensor(&humi, &temp);
    
    if(ret)     // GET DATA OK
    {
        Serial.print("humidity: ");
        Serial.print(humi*100);
        Serial.print("%\t temerature: ");
        Serial.println(temp);
    }
    else        // GET DATA FAIL
    {
        Serial.println("GET DATA FROM AHT20 FAIL");
    }
    
    delay(100);
}
*/

int main(){
signal(SIGINT, handle_sigint);
int bus;
float temp = 0.0;
float humid = 0.0;
unsigned char buffer2[7];
ssize_t size2 = sizeof(buffer2);
char filename[20];


time_t t = time(NULL);
struct tm tm = *localtime(&t);
printf("now: %d-%02d-%02d %02d:%02d:%02d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);


fp = fopen("test.csv", "w+");
fprintf(fp,"sample,i2c_temp,i2c_humid,GPIO0,GPIO1\n");


/* Open i2c bus /dev/i2c-0 */
if ((bus = i2c_open("/dev/i2c-11")) == -1) {

		printf("Error finding bus");
}

I2CDevice device;
memset(&device, 0, sizeof(device));

device.bus = bus;
device.addr = 0x38;
device.iaddr_bytes = 0;
device.page_bytes = 8;

unsigned char buffer[1];
ssize_t size = sizeof(buffer);
unsigned int sample = 0;
int GPIO_0 = 0;
int GPIO_1 = 0;

 
//Exporting Pin 232
GPIO0 = fopen("/sys/class/gpio/export", "w");
fprintf(GPIO0, "232");
fclose(GPIO0);

//Exporting Pin 231
GPIO1 = fopen("/sys/class/gpio/export", "w");
fprintf(GPIO0, "233");
fclose(GPIO1);

while(1){
//0xBE = 190
//Step 0.1 Sending Initializing Byte
memset(buffer, 190, sizeof(buffer));

if ((i2c_ioctl_write(&device, 0, buffer, size)) != size) {

	printf("Could not write");
}



#if DEBUG
printf("Sending (0xBE): %d\n", buffer[0]);
printf("In binary: %s\n\n", toBinary(buffer[0]));
#endif

//Begin Measurement Trigger

//0xac = 172
//Step 0.2: Send Measurement Command
memset(buffer, 172, sizeof(buffer));
if ((i2c_ioctl_write(&device, 0, buffer, size)) != size) {

	printf("Could not write");

}

#if DEBUG
printf("Sending (0xac): %d\n", buffer[0]);
printf("In binary: %s\n\n", toBinary(buffer[0]));
#endif

//0x33 = 51
memset(buffer, 51, sizeof(buffer));

if ((i2c_ioctl_write(&device, 0, buffer, size)) != size) {

	printf("Could not write");
}

#if DEBUG
printf("Sending (0x33): %d\n", buffer[0]);
printf("In binary: %s\n\n", toBinary(buffer[0]));
#endif



memset(buffer, 0, sizeof(buffer));

if ((i2c_ioctl_write(&device, 0, buffer, size)) != size) {

	printf("Could not write");
}

#if DEBUG
printf("Sending (0x00): %d\n", buffer[0]);
printf("In binary: %s\n\n", toBinary(buffer[0]));
#endif
/*
//0x71 = 113
memset(buffer, 0x71, sizeof(buffer));

if ((i2c_ioctl_write(&device, 0, buffer, size)) != size) {

	printf("Could not write");
}



#if DEBUG
printf("Sending (0x71): %d\n", buffer[0]);
printf("In binary: %s\n\n", toBinary(buffer[0]));
#endif

*/
int i = 0;


memset(buffer2, 0, sizeof(buffer2));

waitFor(1);
if ((i2c_ioctl_read(&device, 0, buffer2, size2)) != size2) {

		printf("Could not read\n");
}

#if DEBUG
printf("Reading Data(State): %d\n", buffer2[0]);
printf("Reading Data(Humidity Data 1): %d\n", buffer2[1]);
printf("Reading Data(Humidity Data 2): %d\n", buffer2[2]);
printf("Reading Data(HUMID/TEMP Blend Data 3): %d\n", buffer2[3]);
printf("Reading Data (Temp Data 1): %d\n", buffer2[4]);
printf("Reading Data (Temp Data 2): %d\n", buffer2[5]);
#endif

unsigned long _humi = buffer2[1];
_humi <<= 8;
_humi += buffer2[2];
_humi <<= 4;
_humi += buffer2[3] >> 4;

humid = (float)_humi/1048576.0;

unsigned long __temp = buffer2[3]&0x0f;
__temp <<=8;
__temp += buffer2[4];
__temp <<=8;
__temp += buffer2[5];

temp = (float)__temp/1048576.0*200.0-50.0;
humid = humid * 100;


//Reading in GPIO 0
GPIO0 = fopen("/sys/class/gpio/gpio232/value", "r");
GPIO_0 = fgetc(GPIO0);
fclose(GPIO0);

//Reading in GPIO 1
GPIO0 = fopen("/sys/class/gpio/gpio233/value", "r");
GPIO_0 = fgetc(GPIO0);
fclose(GPIO0);


printf("GPIO 0 state: %d\n", GPIO_0);
printf("GPIO_1 state: %d\n", GPIO_1);
printf("Temperature: %f\n", temp);
printf("Humidity: %f%%\n\n", humid);


fprintf(fp,"%d,%f,%f,%d,%d\n",sample,temp,humid,GPIO_0, GPIO_1);


sample = sample + 1;


fclose(fp);
fp = fopen("test.csv", "a");

#if DEBUG
printf("\n\n\n\nSAVED\n");
#endif

}

i2c_close(bus);
}
